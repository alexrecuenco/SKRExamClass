README:

Template that can be used to generate the answer sheets.


Modify only the commands:
\setcounter{numshortanswer}{10}
\setcounter{nummultiplechoice}{30}
\def\lengthshortanswer{10cm}

to generate an answer sheet