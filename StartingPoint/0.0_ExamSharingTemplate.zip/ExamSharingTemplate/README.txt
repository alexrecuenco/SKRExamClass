README:

To compile LaTeXTemplate.tex as it is:
	-XeLaTeX must be used, not pdflatex.

    - For some useful mathematical definitions, Read and use 
     \usepackage{mytikzmath}


DESCRIPTION:

MidtermTemplate.tex is the file in which you should be writing into.
	- It contains an example of coverpages, where the two pictures BFITS and SKR are used. 

	- Then it contains an example of a multiplechoice section, how different questions can be placed
	- Then an example of short answer questions.


